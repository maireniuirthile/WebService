<?php
/************************************************************************************
* Author: Mary Hurley
*
* TodoDB.class.php : This is the database class. It reads a config.ini file to get the 
* connection details for the database and then goes ahead and creates a connection with mysqli.
* The methods here are : select - which will fetch rows from the database
*                        query -  execute a query thats passed in
*                        quote - which calls mysqli_real_escape_string to escape ' for db insertion
*
* Assignment: WE4.1 Server-side Web Development assignment, Digital Skills Academy
* Student ID: D15128601
* Date : 2016/10/06
* Ref: website link to code referenced or the book, authors name and page number
* http://www.kodingmadesimple.com/2015/01/convert-mysql-to-json-using-php.html
* https://www.binpress.com/tutorial/using-php-with-mysql-the-right-way/17
*************************************************************************************/

class TodoDB {
    
    private static $myConnection;    

    public function __construct(){
            
        // Connect to the database, if a connection has not been established yet
        if (!isset($this->myConnection)) {
            // Load configuration as an array. 
            $config = parse_ini_file('../../config.ini'); 
            $this->myConnection = mysqli_connect($config['host'], $config['username'], $config['password'], $config['dbname'] ) or die ("Error on connect" . mysqli_error($myConnection));
        }
    }

    public function select($query){
        
        //create an array for the todos
        $rows = array();

        //execute the query
        $result = $this->myConnection->query($query);
        if ($result === false) {
            return false;
        }
        
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC) ){
            $rows[] = $row;
        }  
        return $rows;
                
    }
    
    public function query($query){
  
        //execute the query
        $result = $this->myConnection->query($query);
        
    }
    
    /**
     * Quote and escape value for use in a database query
     *
     * @param string $value The value to be quoted and escaped
     * @return string The quoted and escaped string
     */
    public function quote($value) {
        return (mysqli_real_escape_string($this->myConnection, $value));
    }
    
}

?>
