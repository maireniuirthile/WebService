<?php

/**********************************************************
* Author: Mary Hurley
*
* TodoDB.class.php : This is the Todo class. The job of this class is to make a new connection 
* to the Todo Db and create a query to pass in.
* Its methods are are  - addTodo - add a new todo to the db
*                      - listTodos - list all the todos in the database
*                      - updateTodo - which will update the todo to done
*                      - removeTodo - which will delete the todo from the database.
*
*
* Assignment: WE4.1 Server-side Web Development assignment, Digital Skills Academy
* Student ID: D15128601
* Date : 2016/10/06
* Ref: website link to code referenced or the book, authors name and page number
* http://www.kodingmadesimple.com/2015/01/convert-mysql-to-json-using-php.html
* https://www.binpress.com/tutorial/using-php-with-mysql-the-right-way/17

***********************************************************/

class Todo {
    
    private $query;
    private $connection;
    
    public function __construct(){
        
        $this->connection = new TodoDB;  
    }
   
    public function addTodo($name, $job){
       
        // call quote funtion to escape values for use in db query
        
        $name = $this->connection->quote($name);
        $job = $this->connection->quote($job);
        
        // insert name and job values in the todos db
        
        $this->query = "INSERT INTO todos (todoName, todoJob) VALUES ('$name', '$job' )" or die ("Error on insert " . mysqli_error($this->connection));
        
        $this->connection->query($this->query);
     }   
    
    public function listTodos(){

        // select values from the todos database
  
        $this->query = "SELECT todoId, todoName, todoJob, todoDone FROM todos" or die ("Error on select" . mysqli_error($this->$connection));
        $rows = $this->connection->select($this->query);
        if ($rows != false) {
            echo json_encode($rows); // convert php array to json string
        }
    }
    
    public function updateTodo($id, $done){

        // update the done value in the todos database
  
        $this->query = "UPDATE todos SET todoDone = '$done' WHERE todoId='$id' LIMIT 1" or die ("Error on update" . mysqli_error($this->$connection));
        $this->connection->query($this->query);
        
    }
    
    public function deleteTodo($id){
        
        // delete value from the todo database where todoID = $id
        
        $this->query = "DELETE FROM todos WHERE ( todoId = '$id' )" or die ("Error on delete " . mysqli_error($this->connection));
        $this->connection->query($this->query);
        
    }   
}

?>

